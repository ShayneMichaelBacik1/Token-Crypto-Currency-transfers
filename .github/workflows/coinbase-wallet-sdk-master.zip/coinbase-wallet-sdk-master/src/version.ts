export const LIB_VERSION = "3.0.6";
